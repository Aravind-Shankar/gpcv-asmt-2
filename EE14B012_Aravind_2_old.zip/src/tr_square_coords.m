function [ tr_pts ] = tr_square_coords( pts, s )
%TR_SQUARE_COORDS Summary of this function goes here
%   Detailed explanation goes here
tr_pts = [1 1 1; 1 s 1; s s 1; s 1 1];

end

